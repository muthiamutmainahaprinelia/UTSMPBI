# undefined > 2022-06-08 8:23am
https://public.roboflow.ai/classification/undefined

Provided by undefined
License: CC BY 4.0

undefined