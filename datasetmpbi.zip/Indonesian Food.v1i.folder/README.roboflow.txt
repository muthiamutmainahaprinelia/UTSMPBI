
Indonesian Food - v1 2022-06-08 8:23am
==============================

This dataset was exported via roboflow.ai on June 8, 2022 at 1:24 AM GMT

It includes 903 images.
Foods are annotated in folder format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 224x224 (Stretch)

No image augmentation techniques were applied.


